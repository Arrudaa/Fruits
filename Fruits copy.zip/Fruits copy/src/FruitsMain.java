
public class FruitsMain {

	public static void main(String[] args) {
	
		FruitPie orange = new FruitPie("orange", true , "orange", "sour-sweet");
		FruitPie mango = new FruitPie("mango", true ,  "green/orange", "bitter-sweet");
		FruitPie apple = new FruitPie("apple", false, "red", "sweet");
		orange.greeting();
		mango.greeting();
		apple.greeting();
		
	}



	}

