
public class FruitPie {

	//instant variables
		String name;
		boolean seed;
		String colour;
		String flavour;
		//creating the constructor
		public FruitPie(String name, boolean seed, String colour, String flavour) {
			this.name = name;
			this.seed = seed;
			this.colour = colour;
			this.flavour = flavour;
			}
			void greeting() {
				System.out.println("Hello, I'm a delicious fruit, good nutrients, good for health!");
				System.out.println("data: " + this.name + " and " + this.flavour);
			}

	

	
}
